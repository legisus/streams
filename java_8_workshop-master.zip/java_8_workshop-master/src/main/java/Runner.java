import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Runner {


    public static void main(String[] args) {
        List<Employee> team = DataLoader.loadData();

        //1. Вернуть фамилии всех сеньеров


        //2. Найти количество лидов в команде


        //3. Вернуть все скиллы в команде


        //4. Подсчитать среднее сеньорити в команде (джун - 1, миддл - 2, сеньор - 3, лид - 4)


        //5. Вернуть фамилии тех, кто знает джаву


        //6. Вернуть фамилию и тайтл тех, кто знает .Net

    }
}
